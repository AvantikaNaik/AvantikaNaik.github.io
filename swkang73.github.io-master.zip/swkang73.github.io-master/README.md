# Personal Website Resume for Computer Science 


Edited by Sunwoo Kang
Merged CEEVEE with KARDS from Styleshouts :) 


For any questions on starting a personal website for resume, please contact swkang73@stanford.edu / sunnybd97@gmail.com. 

SOURCES AND CREDITS:

Fonts:
 - Inter Font (https://fonts.google.com/specimen/Inter)
 - DM Serif Text Font (https://fonts.google.com/specimen/DM+Serif+Text)
 - DM Serif Display Font (https://fonts.google.com/specimen/DM+Serif+Display)

Icons:
 - Teenyicons (https://teenyicons.com/)
 - FontAwesome (https://fontawesome.com/)

Stock Photos and Graphics:
 - Unsplash.com (https://unsplash.com/)

Javascript Files:
 - JQuery (http://jquery.com/)
 - Modernizr (http://modernizr.com/)
 - Slick slider (http://kenwheeler.github.io/slick/)
 - Animate On Scroll (https://michalsnik.github.io/aos/)
 - PrismJS (https://prismjs.com/)
